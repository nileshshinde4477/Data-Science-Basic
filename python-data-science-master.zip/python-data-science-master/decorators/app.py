def func():
         x=10
         return x
result=func()
print(result)